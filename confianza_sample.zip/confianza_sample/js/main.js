function toggleNav() {
    let body = document.body;
    let hamburger = document.getElementById('js_hamburger');

    hamburger.addEventListener('click', function() {
        body.classList.toggle('nav_open');
    });
}
toggleNav();

$(function(){
    $('a[href^="#"]').click(function(){
      // let speed = 1000;
        let href = $(this).attr("href");
        let target = $(href == "#" || href == "" ? 'html' : href);
        let position = target.offset().top - 20;
        $("html, body").animate({scrollTop:position}, 700, "swing");
        return false;
    });
});